interface Animal {
    String getDrinkingDetails();

    void drink(int amountInMl);
}
