public class DrinkingProcessView {
    public void printDrinkingProcess(String animalDrinkingDetails, String containerDrinkingDetails) {
        System.out.println(animalDrinkingDetails + "\n" + containerDrinkingDetails);
    }
}
