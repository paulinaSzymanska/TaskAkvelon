interface Container {
    void decreaseAmount(int millilitres);

    String getDrinkingDetails();
}
